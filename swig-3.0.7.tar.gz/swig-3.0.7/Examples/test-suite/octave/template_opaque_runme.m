template_opaque

v = template_opaque.OpaqueVectorType(10);

template_opaque.FillVector(v);


